<?php
/**
 * Created by PhpStorm.
 * User: Duo Nuo
 * Date: 2016/7/22
 * Time: 13:21
 */

$arr = array("every" => array("16-03-31" => 0.0607));
echo $arr["every"]["16-03-31"];

?>