<?php
/**
 * Created by PhpStorm.
 * User: Duo Nuo
 * Date: 2016/7/22
 * Time: 11:06
 */
$arr = array("foo" => "bar", 12 => true);

echo $arr["foo"];
echo "\n";
echo $arr[12];

?>